# SPDX-License-Identifier: GPL-3.0-or-later
"""
Butterfly Proboscis (蝶の口吻) add-on.

Geometry Nodes で「くるくる巻いた蝶の口吻」を生成します。
モディファイアの "Uncoil"（0 = 巻いている / 1 = 伸びている）をキーフレームすれば、
水や蜜を飲むときに根元からほどけて伸びるアニメーションが作れます。

形のしくみ:
  口吻を N 個の点で表し、各点の「曲率」を決めて積分（Accumulate Field）して形を作ります。
  - 巻いた状態: アルキメデス螺旋になるように曲率を決定（全長は常に一定）
  - 伸びた状態: ゆるいカーブ（Extended Bend）+ 先端の探るような揺れ（Wiggle）
  - Uncoil の値に応じて、根元から先端に向かって 巻き→伸び に切り替わる
"""

bl_info = {
    "name": "Butterfly Proboscis",
    "author": "naturalart9797-bit",
    "version": (1, 0, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Add > Mesh > Butterfly Proboscis / Sidebar (N) > Butterfly",
    "description": "Procedural coiled butterfly proboscis that can uncoil for drinking",
    "category": "Add Mesh",
}

import math

import bpy
from bpy.props import BoolProperty, FloatProperty, IntProperty
from bpy.types import Operator, Panel

from . import rig

GROUP_NAME = "Butterfly Proboscis"
GROUP_TAG = "butterfly_proboscis_version"
GROUP_VERSION = 4
MATERIAL_NAME = "Butterfly Proboscis"

# Attributes written by the node group (used for automatic UV seams).
ATTR_PART = "proboscis_part"   # face: 0 tube, 1 tip lip/wall, 2 tip bottom, 3 base cap
ATTR_SEAM = "proboscis_seam"   # point: on the lengthwise seam line (angle 0)
EDIT_VERTS_KEY = "proboscis_edit_topology"

# Face winding of the generated cap parts, so their normals match the tube.
FLIP_TIP_WALL = True
FLIP_TIP_BOTTOM = False
FLIP_BASE_CAP = True


# --------------------------------------------------------------------------
# Node tree builder helpers
# --------------------------------------------------------------------------

class _Builder:
    def __init__(self, ng):
        self.ng = ng
        self.nodes = ng.nodes
        self.links = ng.links

    def node(self, bl_idname, **props):
        n = self.nodes.new(bl_idname)
        for key, value in props.items():
            setattr(n, key, value)
        return n

    def feed(self, socket, value):
        if isinstance(value, bpy.types.NodeSocket):
            self.links.new(value, socket)
        elif value is not None:
            socket.default_value = value

    def math(self, op, a, b=None, c=None, label=""):
        n = self.node("ShaderNodeMath", operation=op)
        if label:
            n.label = label
        self.feed(n.inputs[0], a)
        self.feed(n.inputs[1], b)
        self.feed(n.inputs[2], c)
        return n.outputs[0]

    def add(self, a, b):
        return self.math("ADD", a, b)

    def sub(self, a, b):
        return self.math("SUBTRACT", a, b)

    def mul(self, a, b):
        return self.math("MULTIPLY", a, b)

    def div(self, a, b):
        return self.math("DIVIDE", a, b)

    def maximum(self, a, b):
        return self.math("MAXIMUM", a, b)

    def map_range(self, value, from_min, from_max, to_min=0.0, to_max=1.0,
                  smooth=False, label=""):
        n = self.node("ShaderNodeMapRange")
        n.data_type = "FLOAT"
        n.interpolation_type = "SMOOTHSTEP" if smooth else "LINEAR"
        n.clamp = True
        if label:
            n.label = label
        self.feed(n.inputs["Value"], value)
        self.feed(n.inputs["From Min"], from_min)
        self.feed(n.inputs["From Max"], from_max)
        self.feed(n.inputs["To Min"], to_min)
        self.feed(n.inputs["To Max"], to_max)
        return n.outputs["Result"]

    def accumulate_trailing(self, value, label=""):
        """Running sum of `value` over curve points, excluding the current point."""
        n = self.node("GeometryNodeAccumulateField")
        n.data_type = "FLOAT"
        n.domain = "POINT"
        if label:
            n.label = label
        in_sock = next(s for s in n.inputs if s.name == "Value" and s.type == "VALUE")
        out_sock = next(s for s in n.outputs if s.name == "Trailing" and s.type == "VALUE")
        self.feed(in_sock, value)
        return out_sock

    def vmath(self, op, a, b=None, scale=None):
        n = self.node("ShaderNodeVectorMath", operation=op)
        self.feed(n.inputs[0], a)
        self.feed(n.inputs[1], b)
        if scale is not None:
            self.feed(n.inputs["Scale"], scale)
        if op in {"LENGTH", "DOT_PRODUCT", "DISTANCE"}:
            return n.outputs["Value"]
        return n.outputs["Vector"]

    def xyz(self, x=None, y=None, z=None):
        n = self.node("ShaderNodeCombineXYZ")
        self.feed(n.inputs["X"], x)
        self.feed(n.inputs["Y"], y)
        self.feed(n.inputs["Z"], z)
        return n.outputs["Vector"]

    def position(self):
        return self.node("GeometryNodeInputPosition").outputs["Position"]

    def separate(self, vec):
        n = self.node("ShaderNodeSeparateXYZ")
        self.feed(n.inputs[0], vec)
        return n.outputs["X"], n.outputs["Y"], n.outputs["Z"]

    def sample_position(self, geometry, index):
        n = self.node("GeometryNodeSampleIndex")
        n.data_type = "FLOAT_VECTOR"
        n.domain = "POINT"
        self.feed(n.inputs["Geometry"], geometry)
        self.feed(n.inputs["Value"], self.position())
        self.feed(n.inputs["Index"], index)
        return n.outputs["Value"]

    def set_position(self, geometry, position):
        n = self.node("GeometryNodeSetPosition")
        self.feed(n.inputs["Geometry"], geometry)
        self.feed(n.inputs["Position"], position)
        return n.outputs["Geometry"]

    def store(self, geometry, name, value, data_type, domain):
        n = self.node("GeometryNodeStoreNamedAttribute")
        n.data_type = data_type
        n.domain = domain
        self.feed(n.inputs["Geometry"], geometry)
        self.feed(n.inputs["Name"], name)
        sock = next(x for x in n.inputs if x.name == "Value" and x.enabled)
        self.feed(sock, value)
        return n.outputs["Geometry"]

    def switch(self, condition, if_false, if_true):
        n = self.node("GeometryNodeSwitch")
        n.input_type = "GEOMETRY"
        self.feed(n.inputs["Switch"], condition)
        self.feed(next(x for x in n.inputs if x.name == "False" and x.enabled), if_false)
        self.feed(next(x for x in n.inputs if x.name == "True" and x.enabled), if_true)
        return next(x for x in n.outputs if x.enabled)

    def flip(self, mesh):
        n = self.node("GeometryNodeFlipFaces")
        self.feed(n.inputs["Mesh"], mesh)
        return n.outputs["Mesh"]

    def layout(self):
        """Very small auto layout: columns by longest path from the inputs."""
        depth = {n: 0 for n in self.nodes}
        for _ in range(len(self.nodes)):
            changed = False
            for link in self.links:
                d = depth[link.from_node] + 1
                if d > depth[link.to_node]:
                    depth[link.to_node] = d
                    changed = True
            if not changed:
                break
        rows = {}
        for n in self.nodes:
            col = depth[n]
            row = rows.get(col, 0)
            rows[col] = row + 1
            n.location = (col * 220.0, -row * 190.0)


def _new_input(ng, name, socket_type, default=None, min_value=None, max_value=None,
               subtype=None, description=""):
    sock = ng.interface.new_socket(name, in_out="INPUT", socket_type=socket_type,
                                   description=description)
    if subtype:
        try:
            sock.subtype = subtype
        except (AttributeError, TypeError):
            pass
    if default is not None:
        sock.default_value = default
    if min_value is not None:
        sock.min_value = min_value
    if max_value is not None:
        sock.max_value = max_value
    return sock


def _build_node_group():
    ng = bpy.data.node_groups.new(GROUP_NAME, "GeometryNodeTree")
    ng[GROUP_TAG] = GROUP_VERSION
    ng["is_butterfly_proboscis"] = True

    ng.interface.new_socket("Geometry", in_out="INPUT", socket_type="NodeSocketGeometry")
    _new_input(ng, "Uncoil", "NodeSocketFloat", 0.0, 0.0, 1.0, "FACTOR",
               "0 = くるくる巻いた状態 / 1 = まっすぐ伸びた状態（キーフレーム可）")
    _new_input(ng, "Length", "NodeSocketFloat", 1.0, 0.001, 1000.0, "DISTANCE",
               "口吻の全長（巻いていても伸びていても同じ）")
    _new_input(ng, "Turns", "NodeSocketFloat", 3.0, 0.1, 20.0, None,
               "巻き数")
    _new_input(ng, "Inner Radius", "NodeSocketFloat", 0.01, 0.0001, 100.0, "DISTANCE",
               "螺旋の中心（先端側）の半径")
    _new_input(ng, "Straight Base", "NodeSocketFloat", 0.12, 0.0, 0.9, "FACTOR",
               "根元のまっすぐな部分の割合")
    _new_input(ng, "Base Angle", "NodeSocketFloat", math.radians(15.0),
               -math.pi, math.pi, "ANGLE",
               "根元の向き（0 = 前方 +Y、正の値で下向き）")
    _new_input(ng, "Extended Bend", "NodeSocketFloat", math.radians(25.0),
               -math.pi * 2, math.pi * 2, "ANGLE",
               "伸ばしたときの全体の反り（正で下向き）")
    _new_input(ng, "Uncoil Softness", "NodeSocketFloat", 0.15, 0.001, 1.0, "FACTOR",
               "ほどける境目のなめらかさ")
    _new_input(ng, "Wiggle Amount", "NodeSocketFloat", 0.0, -10.0, 10.0, None,
               "伸びた部分の揺れの強さ（水を探る動き）")
    _new_input(ng, "Wiggle Frequency", "NodeSocketFloat", 1.5, 0.0, 20.0, None,
               "揺れの波の数")
    _new_input(ng, "Wiggle Phase", "NodeSocketFloat", 0.0, -1.0e4, 1.0e4, "ANGLE",
               "揺れの位相（アニメーションさせると波が動く）")
    _new_input(ng, "Base Radius", "NodeSocketFloat", 0.01, 0.0, 100.0, "DISTANCE",
               "根元の太さ（半径）")
    _new_input(ng, "Tip Radius", "NodeSocketFloat", 0.004, 0.0, 100.0, "DISTANCE",
               "先端の太さ（半径）")
    _new_input(ng, "Resolution", "NodeSocketInt", 240, 8, 5000, None,
               "長さ方向の分割数")
    _new_input(ng, "Tip Hole Radius", "NodeSocketFloat", 0.5, 0.05, 0.95, "FACTOR",
               "先端の穴の半径（先端の太さに対する割合）")
    _new_input(ng, "Tip Hole Depth", "NodeSocketFloat", 0.8, 0.02, 20.0, None,
               "先端の穴の深さ（先端の太さに対する倍率）")
    _new_input(ng, "Tip Lip", "NodeSocketFloat", 0.6, 0.0, 3.0, None,
               "穴のふちの盛り上がり")
    _new_input(ng, "Profile Resolution", "NodeSocketInt", 16, 8, 256, None,
               "断面の分割数（左右対称にするため 8 の倍数に丸められます）")
    _new_input(ng, "Material", "NodeSocketMaterial", None, None, None, None, "マテリアル")
    _new_input(ng, "Use Edit Mesh", "NodeSocketBool", False, None, None, None,
               "オブジェクトのメッシュ（Edit モードで編集した UV など）を使い、"
               "頂点位置だけを動かす。Make Editable で自動的に ON になります")
    ng.interface.new_socket("Geometry", in_out="OUTPUT", socket_type="NodeSocketGeometry")

    b = _Builder(ng)
    gi = b.node("NodeGroupInput")
    go = b.node("NodeGroupOutput")
    I = gi.outputs  # noqa: E741

    # --- parameterisation ------------------------------------------------
    n_minus_1 = b.math("SUBTRACT", I["Resolution"], 1.0)
    index = b.node("GeometryNodeInputIndex").outputs["Index"]
    s = b.div(index, n_minus_1)                     # 0 .. 1 along the proboscis
    length = b.maximum(I["Length"], 1.0e-4)
    ds = b.div(length, n_minus_1)                   # segment length
    ell_abs = b.mul(s, length)                      # arc length from the base

    # --- coiled curvature: Archimedean spiral with constant length -------
    #   r0 + r_in = Lc / (pi * T),  gap g = (r0 - r_in) / T
    #   r(l)^2 = r0^2 - (g / pi) * l   ->   curvature = 1 / r(l)
    base_len = b.mul(I["Straight Base"], length)
    coil_len = b.maximum(b.sub(length, base_len), 1.0e-4)
    turns = b.maximum(I["Turns"], 0.01)
    r_in = b.maximum(I["Inner Radius"], 1.0e-5)
    r0 = b.sub(b.div(coil_len, b.mul(turns, math.pi)), r_in)
    gap = b.maximum(b.div(b.sub(r0, r_in), turns), 1.0e-6)
    ell = b.maximum(b.sub(ell_abs, base_len), 0.0)
    r_sq = b.maximum(b.sub(b.mul(r0, r0), b.mul(b.div(gap, math.pi), ell)),
                     b.mul(r_in, r_in))
    ramp = b.map_range(ell_abs, b.mul(base_len, 0.4), b.add(base_len, 1.0e-4),
                       smooth=True, label="Straight Base Ramp")
    k_coil = b.mul(b.div(1.0, b.math("SQRT", r_sq)), ramp)

    # --- extended curvature: gentle bend + wiggle -------------------------
    k_bend = b.div(I["Extended Bend"], length)
    wave = b.math("SINE", b.add(b.mul(s, b.mul(I["Wiggle Frequency"], math.tau)),
                                I["Wiggle Phase"]))
    k_wiggle = b.div(b.mul(b.mul(wave, s), I["Wiggle Amount"]), length)
    k_ext = b.add(k_bend, k_wiggle)

    # --- blend: uncoils progressively from the base to the tip -----------
    soft = b.maximum(I["Uncoil Softness"], 0.001)
    front = b.sub(b.mul(I["Uncoil"], b.add(b.mul(soft, 2.0), 1.0)), soft)
    coiled = b.map_range(s, b.sub(front, soft), b.add(front, soft),
                         smooth=True, label="Coiled Factor")
    k = b.add(k_ext, b.mul(coiled, b.sub(k_coil, k_ext)))

    # --- integrate curvature -> angle -> position (YZ plane) -------------
    theta = b.add(I["Base Angle"], b.accumulate_trailing(b.mul(k, ds), "Angle"))
    y = b.accumulate_trailing(b.mul(b.math("COSINE", theta), ds), "Y")
    z = b.mul(b.accumulate_trailing(b.mul(b.math("SINE", theta), ds), "Z"), -1.0)
    pos = b.node("ShaderNodeCombineXYZ")
    b.feed(pos.inputs["Y"], y)
    b.feed(pos.inputs["Z"], z)

    # --- tube -----------------------------------------------------------
    # profile vertex count M, rounded to a multiple of 8: the end caps are filled
    # with a k x k quad grid (outer ring has 4 * (k - 1) verts) and an odd k
    # keeps that grid mirror-symmetric about the YZ plane.
    prof_m = b.mul(b.maximum(b.math("ROUND", b.div(I["Profile Resolution"], 8.0)), 1.0),
                   8.0)
    grid_k = b.add(b.div(prof_m, 4.0), 1.0)

    line = b.node("GeometryNodeCurvePrimitiveLine")
    resample = b.node("GeometryNodeResampleCurve")
    b.feed(resample.inputs["Curve"], line.outputs["Curve"])
    b.feed(resample.inputs["Count"], I["Resolution"])

    curve = b.set_position(resample.outputs["Curve"], pos.outputs["Vector"])

    taper = b.map_range(s, 0.0, 1.0, I["Base Radius"], I["Tip Radius"], label="Taper")
    set_radius = b.node("GeometryNodeSetCurveRadius")
    b.feed(set_radius.inputs["Curve"], curve)
    b.feed(set_radius.inputs["Radius"], taper)
    curve = set_radius.outputs["Curve"]

    # Pin the profile frame: normal = world X (perpendicular to the YZ plane the
    # proboscis lives in). Profile vertex j then sits at cos(a)*X + sin(a)*B,
    # a = 2*pi*j/M, which makes every ring mirror-symmetric about X = 0.
    set_normal = b.node("GeometryNodeSetCurveNormal")
    if "Mode" in set_normal.inputs:          # Blender 4.5+ (menu socket)
        set_normal.inputs["Mode"].default_value = "Free"
    else:
        try:
            set_normal.mode = "FREE"
        except (AttributeError, TypeError):
            pass
    if "Normal" in set_normal.inputs:
        set_normal.inputs["Normal"].default_value = (1.0, 0.0, 0.0)
    b.feed(set_normal.inputs["Curve"], curve)
    curve = set_normal.outputs["Curve"]

    profile = b.node("GeometryNodeCurvePrimitiveCircle")
    b.feed(profile.inputs["Resolution"], prof_m)
    profile.inputs["Radius"].default_value = 1.0

    to_mesh = b.node("GeometryNodeCurveToMesh")
    b.feed(to_mesh.inputs["Curve"], curve)
    b.feed(to_mesh.inputs["Profile Curve"], profile.outputs["Curve"])
    if "Fill Caps" in to_mesh.inputs:
        to_mesh.inputs["Fill Caps"].default_value = False  # caps are built as quads
    if "Scale" in to_mesh.inputs:  # Blender 4.2+: explicit profile scale
        b.feed(to_mesh.inputs["Scale"], taper)
    tube = to_mesh.outputs["Mesh"]
    # UV seam along the symmetry plane, on the inner side of the coil (a = 90 deg)
    tube_seam = b.math("COMPARE", b.math("FLOORED_MODULO",
                                         b.node("GeometryNodeInputIndex").outputs["Index"],
                                         prof_m), b.div(prof_m, 4.0), 0.5)

    # --- end frames, measured from the tube's first / last vertex ring ----
    # Curve to Mesh stores ring i (curve point i) as vertices i*M .. i*M+M-1,
    # profile vertex j sits at angle 2*pi*j/M.
    quarter = b.div(prof_m, 4.0)

    def end_frame(center, neighbour, ring_start):
        v0 = b.sample_position(tube, ring_start)
        v1 = b.sample_position(tube, b.add(ring_start, quarter))
        x_vec = b.vmath("SUBTRACT", v0, center)
        radius = b.vmath("LENGTH", x_vec)
        x_dir = b.vmath("NORMALIZE", x_vec)
        y_dir = b.vmath("NORMALIZE", b.vmath("SUBTRACT", v1, center))
        z_dir = b.vmath("NORMALIZE", b.vmath("SUBTRACT", center, neighbour))
        return center, radius, x_dir, y_dir, z_dir

    def place(geometry, frame, lx, ly, lz):
        """Map local cap coordinates (in units of the end radius) to the frame."""
        center, radius, x_dir, y_dir, z_dir = frame
        world = center
        for d, l in ((x_dir, lx), (y_dir, ly), (z_dir, lz)):
            world = b.vmath("ADD", world, b.vmath("SCALE", d, scale=b.mul(l, radius)))
        return b.set_position(geometry, world)

    last = n_minus_1
    tip_frame = end_frame(b.sample_position(curve, last),
                          b.sample_position(curve, b.sub(last, 1.0)),
                          b.mul(last, prof_m))
    base_frame = end_frame(b.sample_position(curve, 0),
                           b.sample_position(curve, 1),
                           0)

    # --- quad disk: k x k grid warped into concentric, evenly spaced rings --
    def quad_disk():
        grid = b.node("GeometryNodeMeshGrid")
        grid.inputs["Size X"].default_value = 2.0
        grid.inputs["Size Y"].default_value = 2.0
        b.feed(grid.inputs["Vertices X"], grid_k)
        b.feed(grid.inputs["Vertices Y"], grid_k)
        u, v, _ = b.separate(b.position())
        ring = b.maximum(b.math("ABSOLUTE", u), b.math("ABSOLUTE", v))  # 0..1
        side = b.math("ROUND", b.div(b.math("ARCTAN2", v, u), math.pi / 2))
        side_ang = b.mul(side, math.pi / 2)
        along = b.add(b.mul(b.mul(u, -1.0), b.math("SINE", side_ang)),
                      b.mul(v, b.math("COSINE", side_ang)))
        ang = b.add(side_ang, b.mul(b.div(along, ring), math.pi / 4))
        return grid.outputs["Mesh"], ring, ang

    hole_r = b.math("MINIMUM", b.maximum(I["Tip Hole Radius"], 0.05), 0.95)
    hole_d = b.maximum(I["Tip Hole Depth"], 0.02)

    # tip: lip rolls inward from the rim, then a wall down to the hole bottom
    wall = b.node("GeometryNodeMeshCylinder")
    try:
        wall.fill_type = "NONE"
    except (AttributeError, TypeError):
        pass
    b.feed(wall.inputs["Vertices"], prof_m)
    wall.inputs["Side Segments"].default_value = 6
    wall.inputs["Radius"].default_value = 1.0
    wall.inputs["Depth"].default_value = 1.0
    wx, wy, wz = b.separate(b.position())
    w_ang = b.math("ARCTAN2", wy, wx)
    q = b.sub(0.5, wz)                     # 0 = rim (joins the tube) .. 1 = bottom
    lip_part = 4.0 / 6.0
    phi = b.mul(b.math("MINIMUM", b.div(q, lip_part), 1.0), math.pi)
    wall_part = b.maximum(b.div(b.sub(q, lip_part), 1.0 - lip_part), 0.0)
    lip_a = b.mul(b.sub(1.0, hole_r), 0.5)
    lip_c = b.mul(b.add(1.0, hole_r), 0.5)
    w_r = b.add(lip_c, b.mul(lip_a, b.math("COSINE", phi)))
    w_z = b.sub(b.mul(b.mul(lip_a, I["Tip Lip"]), b.math("SINE", phi)),
                b.mul(hole_d, wall_part))
    tip_wall = place(wall.outputs["Mesh"], tip_frame,
                     b.mul(w_r, b.math("COSINE", w_ang)),
                     b.mul(w_r, b.math("SINE", w_ang)), w_z)

    wall_seam = b.math("LESS_THAN", b.math("ABSOLUTE", b.sub(w_ang, math.pi / 2)),
                       b.div(math.pi * 0.5, prof_m))

    disk, d_ring, d_ang = quad_disk()
    d_r = b.mul(d_ring, hole_r)
    tip_bottom = place(disk, tip_frame,
                       b.mul(d_r, b.math("COSINE", d_ang)),
                       b.mul(d_r, b.math("SINE", d_ang)),
                       b.mul(hole_d, -1.0))

    # base: slightly domed quad cap
    disk, d_ring, d_ang = quad_disk()
    base_cap = place(disk, base_frame,
                     b.mul(d_ring, b.math("COSINE", d_ang)),
                     b.mul(d_ring, b.math("SINE", d_ang)),
                     b.mul(b.sub(1.0, b.mul(d_ring, d_ring)), 0.3))

    if FLIP_TIP_WALL:
        tip_wall = b.flip(tip_wall)
    if FLIP_TIP_BOTTOM:
        tip_bottom = b.flip(tip_bottom)
    if FLIP_BASE_CAP:
        base_cap = b.flip(base_cap)

    tube = b.store(tube, ATTR_SEAM, tube_seam, "BOOLEAN", "POINT")
    tip_wall = b.store(tip_wall, ATTR_SEAM, wall_seam, "BOOLEAN", "POINT")
    parts = []
    for part_id, geo in enumerate((tube, tip_wall, tip_bottom, base_cap)):
        parts.append(b.store(geo, ATTR_PART, part_id, "INT", "FACE"))

    join = b.node("GeometryNodeJoinGeometry")
    for geo in parts:
        b.feed(join.inputs["Geometry"], geo)

    merge = b.node("GeometryNodeMergeByDistance")
    b.feed(merge.inputs["Geometry"], join.outputs["Geometry"])
    min_r = b.math("MINIMUM", I["Base Radius"], I["Tip Radius"])
    b.feed(merge.inputs["Distance"], b.maximum(b.mul(min_r, 0.005), 1.0e-7))

    smooth = b.node("GeometryNodeSetShadeSmooth")
    b.feed(smooth.inputs["Geometry"], merge.outputs["Geometry"])

    set_mat = b.node("GeometryNodeSetMaterial")
    b.feed(set_mat.inputs["Geometry"], smooth.outputs["Geometry"])
    b.feed(set_mat.inputs["Material"], I["Material"])
    generated = set_mat.outputs["Geometry"]

    # --- editable mode: keep the object's own mesh (UVs, seams, materials,
    # vertex groups ...) and only move its vertices onto the generated shape.
    # Works while the topology matches; otherwise the mesh is shown unchanged.
    def counts(geo):
        n = b.node("GeometryNodeAttributeDomainSize")
        n.component = "MESH"
        b.feed(n.inputs["Geometry"], geo)
        return n.outputs["Point Count"], n.outputs["Face Count"]

    gen_pts, gen_faces = counts(merge.outputs["Geometry"])
    in_pts, in_faces = counts(I["Geometry"])
    same = b.mul(b.math("COMPARE", gen_pts, in_pts, 0.5),
                 b.math("COMPARE", gen_faces, in_faces, 0.5))
    same_bool = b.node("FunctionNodeCompare")
    same_bool.data_type = "FLOAT"
    same_bool.operation = "GREATER_THAN"
    b.feed(same_bool.inputs["A"], same)
    same_bool.inputs["B"].default_value = 0.5

    deformed = b.set_position(
        I["Geometry"],
        b.sample_position(merge.outputs["Geometry"],
                          b.node("GeometryNodeInputIndex").outputs["Index"]))
    edited = b.switch(same_bool.outputs["Result"], I["Geometry"], deformed)
    result = b.switch(I["Use Edit Mesh"], generated, edited)
    b.feed(go.inputs["Geometry"], result)

    b.layout()
    return ng


def get_node_group():
    for ng in bpy.data.node_groups:
        if ng.bl_idname == "GeometryNodeTree" and ng.get(GROUP_TAG) == GROUP_VERSION:
            return ng
    return _build_node_group()


def get_material():
    mat = bpy.data.materials.get(MATERIAL_NAME)
    if mat is None:
        mat = bpy.data.materials.new(MATERIAL_NAME)
        mat.diffuse_color = (0.08, 0.05, 0.03, 1.0)
        try:
            mat.use_nodes = True
            bsdf = mat.node_tree.nodes.get("Principled BSDF")
            if bsdf:
                bsdf.inputs["Base Color"].default_value = (0.08, 0.05, 0.03, 1.0)
                bsdf.inputs["Roughness"].default_value = 0.35
        except (AttributeError, KeyError):
            pass
    return mat


# --------------------------------------------------------------------------
# Modifier helpers
# --------------------------------------------------------------------------

def input_identifiers(ng):
    return {
        item.name: item.identifier
        for item in ng.interface.items_tree
        if item.item_type == "SOCKET" and item.in_out == "INPUT"
    }


def find_proboscis_modifier(obj):
    if obj is None:
        return None
    for mod in obj.modifiers:
        if (mod.type == "NODES" and mod.node_group is not None
                and mod.node_group.get("is_butterfly_proboscis")):
            return mod
    return None


def _input_ref(mod, name):
    """Return (owner, prop_name, data_path) for a modifier input.

    Blender 5.2+ stores inputs as RNA structs (mod.properties.inputs.<id>.value),
    older versions store them as ID properties (mod["<id>"]).
    """
    ident = input_identifiers(mod.node_group).get(name)
    if ident is None:
        return None
    props = getattr(mod, "properties", None)
    inputs = getattr(props, "inputs", None)
    if inputs is not None:
        sock = getattr(inputs, ident, None)
        if sock is not None and hasattr(sock, "value"):
            return sock, "value", sock.path_from_id("value")
    return mod, f'["{ident}"]', f'modifiers["{mod.name}"]["{ident}"]'


def set_input(mod, name, value):
    ref = _input_ref(mod, name)
    if ref is None:
        return
    owner, prop, _ = ref
    if prop == "value":
        owner.value = value
    else:
        owner[prop[2:-2]] = value


def get_input(mod, name):
    ref = _input_ref(mod, name)
    if ref is None:
        return None
    owner, prop, _ = ref
    return owner.value if prop == "value" else owner.get(prop[2:-2])


def keyframe_input(obj, mod, name, value, frame):
    set_input(mod, name, value)
    _, _, data_path = _input_ref(mod, name)
    obj.keyframe_insert(data_path=data_path, frame=frame)


# --------------------------------------------------------------------------
# Operators
# --------------------------------------------------------------------------

class OBJECT_OT_add_butterfly_proboscis(Operator):
    """くるくる巻いた蝶の口吻を追加"""
    bl_idname = "object.add_butterfly_proboscis"
    bl_label = "Butterfly Proboscis"
    bl_options = {"REGISTER", "UNDO"}

    length: FloatProperty(name="Length", default=1.0, min=0.001, unit="LENGTH")
    turns: FloatProperty(name="Turns", default=3.0, min=0.1, max=20.0)
    inner_radius: FloatProperty(name="Inner Radius", default=0.01, min=0.0001,
                                unit="LENGTH")
    base_radius: FloatProperty(name="Base Radius", default=0.01, min=0.0, unit="LENGTH")
    tip_radius: FloatProperty(name="Tip Radius", default=0.004, min=0.0, unit="LENGTH")
    uncoil: FloatProperty(name="Uncoil", default=0.0, min=0.0, max=1.0, subtype="FACTOR")
    parent_to_active: BoolProperty(
        name="Parent to Active",
        description="選択中のアクティブオブジェクト（頭など）の子にする",
        default=True,
    )

    def execute(self, context):
        active = context.active_object
        if active is not None and not active.select_get():
            active = None

        if context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")

        ng = get_node_group()
        mesh = bpy.data.meshes.new("Proboscis")
        mesh.materials.append(get_material())
        obj = bpy.data.objects.new("Proboscis", mesh)
        context.collection.objects.link(obj)
        obj.location = context.scene.cursor.location

        mod = obj.modifiers.new("Proboscis", "NODES")
        mod.node_group = ng
        set_input(mod, "Length", self.length)
        set_input(mod, "Turns", self.turns)
        set_input(mod, "Inner Radius", self.inner_radius)
        set_input(mod, "Base Radius", self.base_radius)
        set_input(mod, "Tip Radius", self.tip_radius)
        set_input(mod, "Uncoil", self.uncoil)
        set_input(mod, "Material", get_material())

        if self.parent_to_active and active is not None:
            obj.parent = active
            obj.matrix_parent_inverse = active.matrix_world.inverted()

        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        return {"FINISHED"}


class OBJECT_OT_proboscis_drink_keys(Operator):
    """口吻を 伸ばす → 水を飲む（探る）→ 巻き戻す キーフレームを打つ"""
    bl_idname = "object.proboscis_drink_keys"
    bl_label = "Add Drinking Animation"
    bl_options = {"REGISTER", "UNDO"}

    start_frame: IntProperty(name="Start Frame", default=1)
    extend_frames: IntProperty(name="Extend", description="伸ばすのにかかるフレーム数",
                               default=24, min=1)
    drink_frames: IntProperty(name="Drink", description="飲んでいる時間（フレーム）",
                              default=60, min=0)
    retract_frames: IntProperty(name="Retract", description="巻き戻すフレーム数",
                                default=36, min=1)
    max_uncoil: FloatProperty(name="Max Uncoil", default=1.0, min=0.0, max=1.0,
                              subtype="FACTOR")
    probe: BoolProperty(name="Probe (Wiggle)",
                        description="飲んでいる間、先端を揺らして探る動きを付ける",
                        default=True)
    wiggle_amount: FloatProperty(name="Wiggle Amount", default=0.6)
    wiggle_cycles: FloatProperty(name="Wiggle Cycles", default=2.0, min=0.0)

    @classmethod
    def poll(cls, context):
        return find_proboscis_modifier(context.active_object) is not None

    def invoke(self, context, event):
        self.start_frame = context.scene.frame_current
        return self.execute(context)

    def execute(self, context):
        obj = context.active_object
        mod = find_proboscis_modifier(obj)
        f0 = self.start_frame
        f1 = f0 + self.extend_frames
        f2 = f1 + self.drink_frames
        f3 = f2 + self.retract_frames

        keyframe_input(obj, mod, "Uncoil", 0.0, f0)
        keyframe_input(obj, mod, "Uncoil", self.max_uncoil, f1)
        keyframe_input(obj, mod, "Uncoil", self.max_uncoil, f2)
        keyframe_input(obj, mod, "Uncoil", 0.0, f3)

        if self.probe:
            phase0 = get_input(mod, "Wiggle Phase") or 0.0
            keyframe_input(obj, mod, "Wiggle Amount", 0.0, f0)
            keyframe_input(obj, mod, "Wiggle Amount", self.wiggle_amount, f1)
            keyframe_input(obj, mod, "Wiggle Amount", self.wiggle_amount, f2)
            keyframe_input(obj, mod, "Wiggle Amount", 0.0, f3)
            keyframe_input(obj, mod, "Wiggle Phase", phase0, f0)
            keyframe_input(obj, mod, "Wiggle Phase",
                           phase0 + math.tau * self.wiggle_cycles, f3)

        set_input(mod, "Uncoil", 0.0)
        context.scene.frame_set(context.scene.frame_current)
        obj.update_tag()
        self.report({"INFO"}, f"Drinking animation: frames {f0}-{f3}")
        return {"FINISHED"}


def _evaluated_generated_mesh(context, obj, mod):
    """Return a new Mesh datablock with the procedural shape at its current pose."""
    set_input(mod, "Use Edit Mesh", False)
    obj.update_tag()
    depsgraph = context.evaluated_depsgraph_get()
    depsgraph.update()
    eval_obj = obj.evaluated_get(depsgraph)
    return bpy.data.meshes.new_from_object(eval_obj, preserve_all_data_layers=True,
                                           depsgraph=depsgraph)


def _clean_material_slots(mesh):
    """Drop empty / unused material slots and remap face material indices."""
    used = {p.material_index for p in mesh.polygons}
    keep = [i for i, m in enumerate(mesh.materials) if m is not None and i in used]
    if len(keep) == len(mesh.materials):
        return
    remap = {old: new for new, old in enumerate(keep)}
    indices = [remap.get(p.material_index, 0) for p in mesh.polygons]
    mats = [mesh.materials[i] for i in keep]
    mesh.materials.clear()
    for m in mats:
        mesh.materials.append(m)
    for p, i in zip(mesh.polygons, indices):
        p.material_index = i


def _replace_mesh(obj, mesh):
    _clean_material_slots(mesh)
    old = obj.data
    mesh.name = old.name
    obj.data = mesh
    if old.users == 0:
        bpy.data.meshes.remove(old)


def mark_proboscis_seams(mesh):
    """Seams between tube / tip / base parts plus one lengthwise line."""
    part = mesh.attributes.get(ATTR_PART)
    seam = mesh.attributes.get(ATTR_SEAM)
    if part is None or seam is None:
        return False
    face_part = [d.value for d in part.data]
    on_line = [d.value for d in seam.data]
    edge_faces = {}
    for poly in mesh.polygons:
        for key in poly.edge_keys:
            edge_faces.setdefault(key, []).append(face_part[poly.index])
    for edge in mesh.edges:
        a, b = edge.vertices
        fp = edge_faces.get(edge.key, [])
        edge.use_seam = (len(set(fp)) > 1
                         or (on_line[a] and on_line[b] and all(p in (0, 1) for p in fp)))
    return True


def is_edit_mesh_mode(mod):
    return bool(get_input(mod, "Use Edit Mesh"))


_TOPOLOGY_INPUTS = ("Resolution", "Profile Resolution")


def _topology_signature(obj, mod):
    return [len(obj.data.vertices), len(obj.data.polygons)] + [
        int(get_input(mod, n) or 0) for n in _TOPOLOGY_INPUTS]


def edit_mesh_matches(obj, mod):
    stored = obj.get(EDIT_VERTS_KEY)
    return stored is not None and list(stored) == _topology_signature(obj, mod)


class OBJECT_OT_proboscis_make_editable(Operator):
    """口吻を実体のメッシュにして Edit モードで編集可能にする（Uncoil アニメーションは維持）"""
    bl_idname = "object.proboscis_make_editable"
    bl_label = "Make Editable (Keep Animation)"
    bl_options = {"REGISTER", "UNDO"}

    auto_uv: BoolProperty(name="Auto Seams + UV Unwrap",
                          description="シームを自動で入れて UV 展開する",
                          default=True)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.type == "MESH"
                and find_proboscis_modifier(obj) is not None)

    def execute(self, context):
        obj = context.active_object
        mod = find_proboscis_modifier(obj)
        if obj.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")

        mesh = _evaluated_generated_mesh(context, obj, mod)
        _replace_mesh(obj, mesh)
        obj[EDIT_VERTS_KEY] = _topology_signature(obj, mod)
        set_input(mod, "Use Edit Mesh", True)

        if self.auto_uv and mark_proboscis_seams(mesh):
            if not mesh.uv_layers:
                mesh.uv_layers.new(name="UVMap")
            bpy.ops.object.mode_set(mode="EDIT")
            bpy.ops.mesh.select_all(action="SELECT")
            bpy.ops.uv.unwrap(method="ANGLE_BASED", margin=0.002)
            bpy.ops.object.mode_set(mode="OBJECT")

        obj.update_tag()
        self.report({"INFO"}, "Edit モードで UV・マテリアル等を編集できます")
        return {"FINISHED"}


class OBJECT_OT_proboscis_apply_mesh(Operator):
    """今の形で普通のメッシュに確定する（モディファイアを外す / アニメーションは無くなる）"""
    bl_idname = "object.proboscis_apply_mesh"
    bl_label = "Apply as Mesh (Freeze)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return find_proboscis_modifier(context.active_object) is not None

    def execute(self, context):
        obj = context.active_object
        mod = find_proboscis_modifier(obj)
        if obj.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        obj.update_tag()
        depsgraph = context.evaluated_depsgraph_get()
        depsgraph.update()
        mesh = bpy.data.meshes.new_from_object(obj.evaluated_get(depsgraph),
                                               preserve_all_data_layers=True,
                                               depsgraph=depsgraph)
        obj.modifiers.remove(mod)
        _replace_mesh(obj, mesh)
        mark_proboscis_seams(mesh)
        if EDIT_VERTS_KEY in obj:
            del obj[EDIT_VERTS_KEY]
        return {"FINISHED"}


# --------------------------------------------------------------------------
# UI
# --------------------------------------------------------------------------

_PANEL_GROUPS = (
    ("Animation", ("Uncoil", "Wiggle Amount", "Wiggle Frequency", "Wiggle Phase")),
    ("Shape", ("Length", "Turns", "Inner Radius", "Straight Base", "Base Angle",
               "Extended Bend", "Uncoil Softness")),
    ("Thickness / Tip", ("Base Radius", "Tip Radius", "Tip Hole Radius",
                         "Tip Hole Depth", "Tip Lip", "Resolution",
                         "Profile Resolution", "Material")),
)


class VIEW3D_PT_butterfly_proboscis(Panel):
    bl_label = "Butterfly Proboscis"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Butterfly"

    def draw(self, context):
        layout = self.layout
        layout.operator(OBJECT_OT_add_butterfly_proboscis.bl_idname, icon="ADD",
                        text="Add Proboscis")

        obj = context.active_object
        if rig.draw_rig_panel(layout, context):
            return
        mod = find_proboscis_modifier(obj)
        if mod is None:
            layout.label(text="口吻オブジェクトを選択してください", icon="INFO")
            return

        for title, names in _PANEL_GROUPS:
            box = layout.box()
            box.label(text=title)
            col = box.column(align=True)
            for name in names:
                ref = _input_ref(mod, name)
                if ref is None:
                    continue
                owner, prop, _ = ref
                if name == "Material" and prop != "value":
                    col.prop_search(owner, prop, bpy.data, "materials", text=name)
                else:
                    col.prop(owner, prop, text=name)
            if title == "Animation":
                box.label(text="値の上で I キー → キーフレーム", icon="KEYFRAME")

        layout.operator(OBJECT_OT_proboscis_drink_keys.bl_idname, icon="MOD_FLUID")

        box = layout.box()
        box.label(text="Edit Mode", icon="EDITMODE_HLT")
        if is_edit_mesh_mode(mod):
            if edit_mesh_matches(obj, mod):
                box.label(text="編集可能（UV・マテリアル等）", icon="CHECKMARK")
            else:
                box.label(text="頂点数・分割数が変わったので形が動きません", icon="ERROR")
                box.label(text="元に戻すか Rebuild してください")
            box.operator(OBJECT_OT_proboscis_make_editable.bl_idname,
                         text="Rebuild Mesh（UV はリセット）", icon="FILE_REFRESH")
            box.prop(*_input_ref(mod, "Use Edit Mesh")[:2], text="Use Edit Mesh")
        else:
            box.operator(OBJECT_OT_proboscis_make_editable.bl_idname, icon="UV")
        box.operator(OBJECT_OT_proboscis_apply_mesh.bl_idname, icon="CHECKMARK")

        box = layout.box()
        box.label(text="Bone Rig", icon="ARMATURE_DATA")
        box.label(text="頭のボーンに付けて、伸ばすと目標へ届くリグを作る")
        box.operator(rig.OBJECT_OT_proboscis_generate_rig.bl_idname, icon="BONE_DATA")


def menu_func(self, context):
    self.layout.operator(OBJECT_OT_add_butterfly_proboscis.bl_idname, icon="CURVE_PATH")


_classes = (
    OBJECT_OT_add_butterfly_proboscis,
    OBJECT_OT_proboscis_drink_keys,
    OBJECT_OT_proboscis_make_editable,
    OBJECT_OT_proboscis_apply_mesh,
    VIEW3D_PT_butterfly_proboscis,
)


def register():
    for cls in _classes + rig.classes:
        bpy.utils.register_class(cls)
    bpy.types.VIEW3D_MT_mesh_add.append(menu_func)


def unregister():
    bpy.types.VIEW3D_MT_mesh_add.remove(menu_func)
    for cls in reversed(_classes + rig.classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
